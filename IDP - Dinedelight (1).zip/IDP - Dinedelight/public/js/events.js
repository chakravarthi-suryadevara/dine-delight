function showDetails() {
    const festival = document.getElementById('festival').value;
  
    const eventDetails = {
      diwali: {
        events: 'Laxmi Puja, Fireworks, Diya Lighting',
        menu: 'Sweets (Ladoo, Jalebi), Snacks (Samosa, Kachori), Main (Paneer Butter Masala, Naan)'
      },
      christmas: {
        events: 'Christmas Tree Lighting, Carol Singing, Santa Claus Visit',
        menu: 'Roast Chicken, Plum Cake, Hot Chocolate'
      },
      eid: {
        events: 'Special Prayers, Zakat, Eid Feast',
        menu: 'Biryani, Sheer Khurma, Kebabs'
      },
      newyear: {
        events: 'Fireworks, Countdown Party, New Year Toast',
        menu: 'Pasta, Grilled Chicken, Ice Cream'
      },
      pongal: {
        events: 'Pongal Celebration, Harvest Prayers, Rangoli Art',
        menu: 'Ven Pongal, Sakkarai Pongal, Coconut Chutney'
      },
      holi: {
        events: 'Color Throwing, Music and Dance, Bonfires',
        menu: 'Gujiya, Bhang Thandai, Puran Poli'
      },
      thanksgiving: {
        events: 'Family Dinner, Gratitude Sharing, Turkey Carving',
        menu: 'Roast Turkey, Mashed Potatoes, Pumpkin Pie'
      },
      rakshabandhan: {
        events: 'Tying of Rakhi, Gifts Exchange, Family Gatherings',
        menu: 'Mithai (Sweets), Puri Bhaji, Kheer'
      },
      navratri: {
        events: 'Garba Dance, Durga Puja, Fasting and Celebrations',
        menu: 'Sabudana Khichdi, Kuttu Roti, Aloo Sabzi'
      },
      durgapuja: {
        events: 'Pandal Hopping, Durga Idol Immersion, Cultural Programs',
        menu: 'Khichuri, Beguni, Sandesh, Rasgulla, Bhog (Rice, Dal, Mixed Vegetables)'
      },
      ganeshchaturthi: {
        events: 'Ganesh Idol Installation, Aarti, Ganesh Visarjan (Immersion)',
        menu: 'Modak, Puran Poli, Chivda, Vada Pav'
      }
    };
  
    // Update the events section
    const eventsDiv = document.getElementById('events');
    eventsDiv.innerHTML = `<h2>Events</h2><p>${eventDetails[festival]?.events || 'No events available'}</p>`;
  
    // Update the food menu section
    const menuDiv = document.getElementById('menu');
    menuDiv.innerHTML = `<h2>Food Menu</h2><p>${eventDetails[festival]?.menu || 'No food menu available'}</p>`;
  }
  