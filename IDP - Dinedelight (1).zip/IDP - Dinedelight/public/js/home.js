document.addEventListener('DOMContentLoaded', () => {
    // Get the button and form elements
    const reserveTableBtn = document.getElementById('reserveTableBtn');
    const reservationForm = document.getElementById('reservationForm');

    // Check if elements are correctly selected
    if (reserveTableBtn && reservationForm) {
        // Toggle the visibility of the reservation form
        reserveTableBtn.addEventListener('click', (event) => {
            event.preventDefault(); // Prevent link from navigating
            // Toggle the display property of the reservation form
            reservationForm.style.display = 
                reservationForm.style.display === 'none' ? 'block' : 'none';
        });
    } else {
        console.error("Element(s) not found!");
    }
});
